<html>
<head>
   <title> REGISTER FORM</title>
    <style>
        body{
            background-image: url("wp1848606.jpg");
            background-size: 100% 700px;
            background-repeat: no-repeat;
        }
        h1{
            color: cadetblue;
            text-align: left;
            color:firebrick;
            font-family:cursive;
            font-weight: bold;
         }
      /*  .register{
            background: #051019;
            opacity: 0.9;
            width: 500px;
            margin: 0px 0px 0px 480px;
            color: white;
            font-size: 18px;
            padding: 20px;
            border-radius: 10px;
        }*/
        #register{
            margin-left: 50px;
        }
        label{
            color: white;
            font-family: sans-serif;
            font-size:20px;
            font-style: normal;
        }
        #butt{
            width: 200px;
            padding: 10px;
            font-size: 16px;
            font-style: sans-serif;
            font-weight: 600px;
            border: none;
            border-radius: 10px;
            outline: 0;
            background-color:white;
        }
        .register input[type="submit"]
        {
            border: none;
            outline: none;
            height: 40px;
            background: #fb2525;
            color: blue;
            border-radius: 20px;

        }
        .error{
            color:#FF0000;
        }
        input[type=text] {
  width: 25%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: none;
  border-bottom: 2px solid black;
}

    </style>
</head>
<body>
    <br>
    <center>
   <h1>....WELCOME....</h1><br>
   <div class ="register">
   <form method="post"id="register" action="sample_user.php">
     
	 	 <label>First Name</label><br>	
		 <input type="text" name="fname" id= "name" placeholder="enter your first name"><br><br>
		 
		 <label>Last name</label><br>
         <input type="text" name="lname" id= "lname" placeholder="enter your surname"><br><br>
		 	
		
		 <label>Disease name</label><br>
		 <input type="text" name="dname" id= "dname" placeholder="enter your disease" required>
       <span class="error">*</span><br><br>
		 
		 
		 <label>City name</label><br>
		 <input type="text" name="cname" id= "cname" placeholder="enter your city name" required>
       <span class="error">*</span><br><br><br>
		 <input type="submit"  value="Search" name="search" id="butt" style="font-weight: bold">
		
		 
		 
		 
		 
   
   </form>
   </div>
    </center>
</body>


</html>

