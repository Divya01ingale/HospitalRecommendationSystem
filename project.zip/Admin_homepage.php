<html>
	<head>
		<title>Admin_Page</title>
	<style>
	
body {
	
	background-image: url("bg.jpg");
    
	background-repeat:no-repeat;
       
	background-size:cover;
} 


	</style>
	<style>
	.button {
 	 background-color: #555555;
	 border: none;
  	 color: white;
	  padding: 15px 32px;
 	 text-align: center;
 	 text-decoration: none;
 	 display: inline-block;
	  font-size: 16px;
	  margin: 15px 10px;
 	 cursor: pointer;
	}
	</style>

	</head>
	<body>
	   <center>
           <br><br><br>
		<a href="Add_hospital.php"><input type="button" class="button" value="Add Hospital"  ></a>
		<br><br>
		<a href="remove_hospital.php"><input type="button" class="button" value="Remove Hospital"></a>
		<br><br>
           <a href="display-update.php"><input type="button" class="button" value="Update Hospital"></a>
		<br><br>
		<a href="table.php"><input type="button" class="button" value="Register hospital"></a>
		<br><br>
	   </center>
	</body>
</html>