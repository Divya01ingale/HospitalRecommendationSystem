<html>
	<head>
    
		<title>Add Hospital</title>
		<style>
            
    body{
	
	background-image: url("bg.jpg");
        
	background-repeat:no-repeat;
       
	background-size:cover;
} 
            .serif {
  font-family: "Times New Roman", Times, serif;
                 font-size: 20px;
                
}
            body {
  color: white;
}
    
input[type=text] {
  width: 25%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid blue;
  border-radius: 4px;
}
         

            input[type=time] {
  width: 10%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid blue;
  border-radius: 4px;
}
            textarea {
  width: 25%;
  height: 100px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid blue;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-size: 16px;
  resize: none;
}

		.button {
  background-color: blue; 
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}
    .button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}
            h1 {
  color: green;
                 font-size: 40px;
}
            .error {color: #FF0000;}
		</style>

	</head>
	<body>
	<b>
   
       <form action="action.php" method="post">
	<fieldset>
    
    <b>
        <div class="serif">
         <h1>  Hospital Information</h1>
        <center>
	
        
             <tr>
                 <td>Hospital Name:  </td><td> <input type="text"  name="hname" placeholder="Enter the Hospital Name"id="hname" required>
                 <span class="error">*</span></td>
                 </tr>
	<br><br>
             <tr>
              <td> 
                  Doctor Name:   </td><td><input type="text" name="drname" placeholder="Enter the Doctor Name" id="drname" required>
                 <span class="error">*</span></td> 
            </tr>
	<br><br>
             
            <tr>   
                <td>Hospital address : </td><td>  <textarea name="haddress" cols="25" rows="3"id="haddress" placeholder="Hospital Address" required> </textarea>
                <span class="error">*</span></td> 
            </tr>
     <br><br><br>
             
                     <tr>
                         <td>Disease Name: </td><td>  <input type="text" name="dname" placeholder="Enter the Disease Name" id="dname" required>
                         <span class="error">*</span> </td>
            </tr>
	<br><br><br>
             
               <tr>
                   <td> Hospital time:  </td> <td><input type="time" name="stime" id="shtime" > To <input type="time" name="etime" id="ehtime" >
                   </td>
            </tr>
     <br><br><br>
             
            <tr>   
                <td>Hospital contact no:  </td><td> <input type="text" name="contno" placeholder="Enter the contact no" id="cont_no" required>
                <span class="error">*</span> </td>
            </tr>
	<br><br><br>
             
             <tr>
                 <td>Hospital city: </td><td>  <input type="text" name="cityname" placeholder="Enter the City" id="cname" required>
                 <span class="error">*</span></td> 
            </tr>
	 <br><br><br>
             
           <tr>
               <td>Hospital Rates  : </td> <td>ICU : </td> <td> <input type="text" name="icurate"                                id="rates" required>
               <span class="error">*</span></td> 
                             <br><br>
               <td>special room :   </td> <td><input type="text" name="splrate" id="rates" required>
               <span class="error">*</span></td> 
                            <br><br>
               <td>semi Special  : </td> <td> <input type="text" name="semisplrate" id="rates" required>
               <span class="error">*</span></td> 
                            <br><br>
               <td> General ward  : </td> <td> <input type="text" name="generalrate" id="rates" required>
               <span class="error">*</span></td>
             
            </tr>
	 <br><br><br><br>
	
            
            <input type="Submit" class="button button2" name="btn" value="Add Hospital">
            
        </center>
        </div>
    </b>
    </fieldset>
       </form>
        </b>
    </body>
</html>