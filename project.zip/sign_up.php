<html>
	<head>
        
        <style> 
            
    body{
	
	background-image: url("bg1.jpg");
        
	background-repeat:no-repeat;
       
	background-size:cover;
}
input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: none;
  border-bottom: 2px solid black;
}
input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: none;
  border-bottom: 2px solid black;
}
input[type=date] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: none;
  border-bottom: 2px solid black;
}
            
.serif {
  font-family: "Times New Roman", Times, serif;
                font-size: 20px;
                
}
            body {
  color: white;
}
             .button {
  background-color: blue; 
  border: blue;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
                float: right
}
    .button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}
            h1 {
                font-family:sans-serif;
  color: black;
                 font-size: 40px;
}
        
</style>
	</head>
	<body>
        <b>
       
        <h1>Welcome to our signup page........</h1>
		<form action="sign_up_save.php" method="post">
            <center>
            <br>
                <div class="serif">
                <table>
                    <tr>
                        <td><label>Hospital Name :</label></td>
                        <td><input type="text" placeholder="Enter hospital name" name="hospname"><br><br></td>
                    </tr>
            <tr>
            <br>
                <td><label>Password :</label></td>
                <td><input type="password" placeholder="Enter the password" name="password"><br><br></td>
                    </tr>
			<tr>
                <td><label>Contact No :</label></td>
                <td><input type="text" placeholder="Enter the contact no" name="contno"><br><br></td>
                    </tr>
			<tr>
                <td><label>Registered By :</label></td>
                <td><input type="text" placeholder="Enter the name" name="rname"><br><br></td>
                    </tr>
			<tr>
                <td><label>Registration Date :</label></td>
                <td><input type="date" name="rdate" ><br></td>
                    </tr>
                </table>
			<input type="submit" class="button button2" value="Register">
                </div>
            </center>
		</form>
        </b>
	</body>
</html>