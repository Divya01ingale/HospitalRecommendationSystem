
<?php
$hospname=$_REQUEST['hospname'];
$password=$_REQUEST['password'];
$mobile=$_REQUEST['contno'];
$rname=$_REQUEST['rname'];
$rdate=$_REQUEST['rdate'];




$conn=mysqli_connect("localhost","root","","project");
$q="insert into user values('$hospname','$password','$mobile','$rname','$rdate')";
$result=mysqli_query($conn,$q);
if($result)
{
	echo "<script>alert('Inserted successfully');</script>";
}else{
	echo "<script>alert('Fail To insert, please try again');window.location='sign_up.php';</script>";}
?>