<html>
    <head>
        <style>
            body{
	
	background-image: url("bg.jpg");
        
	background-repeat:no-repeat;
       
	background-size:cover;
                
}
            input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid blue;
  border-radius: 4px;
}
             input[type=time] {
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid blue;
  border-radius: 4px;
}
            textarea {
  width: 100%;
  height: 80px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid blue;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-size: 16px;
  resize: none;
}
           .serif {
  font-family: "Times New Roman", Times, serif;
                font-size: 20px;
                
}
            body {
  color: white;
}
            .button {
  background-color: blue; 
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
                float: right
}
    .button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}
            h1 {
  color: black;
                 font-size: 40px;
}
        
        </style> 
    </head>
    <body>
        <?php
		$hospital_id=$_REQUEST['hospital_id'];
		$conn=mysqli_connect("localhost","root","","project");
		$res=mysqli_query($conn,"select * from hospital where hospital_id='$hospital_id'");
		$data=mysqli_fetch_array($res);
        ?>
        <form  method="post">
            <h1>Hospital Details</h1>
			<center>
                <table>
            <div class="serif">
			<input type="hidden" readonly name="hospital_id" value='<?php echo $hospital_id; ?>'>
			<tr>
                <td><label>Hospital Name : </label></td>
                <td><input type="text" name="lname"  value='<?php echo $data['hospital_name']; ?> '><br><br>
                           </td>
                </tr>
                
                <tr>
                    <td><label>Hospital Address : </label></td>
                    <td><input type="text" name="hname"  value='<?php echo $data['hospital_address'];?> '></td><br><br>
                </tr>
                <tr>
                    <td><label>Doctor Name : </label></td>
                    <td><input type="text" name="lname"  value='<?php echo $data['doctor_name'];?> '></td><br><br>
                </tr>
                <tr>
                    <td><label>Contact No : </label></td>
                    <td><input type="text" name="lname"  value='<?php echo $data['cont_no'];?> '><br><br></td>
                </tr>
                <tr>
                    <td><label>Hospital Time : </label></td>
                    <td><input type="time" name="lname"  value=' <?php echo $data['hosp_start_time']; ?> '> TO <input type="time" name="lname"  value='<?php echo $data['hosp_end_time']; ?> '></td><br><br>
                </tr>
                <tr>
                    <td><label>Hospital City : </label></td>
                    <td><input type="text" name="lname"  value='<?php echo $data['city_name'];?> '></td><br><br>
                </tr>
                <tr>
                    <td><label>Disease Name : </label></td>
                    <td><input type="text" name="lname"  value='<?php echo $data['disease_name'];?> '></td><br><br>
                </tr>
                <tr>
                    <td><label>ICU rate : </label></td>
                    <td><input type="text" name="lname"  value='<?php echo $data['hrate_ICU'];?> '><br></td>
                </tr>
                <tr>
                    <label><td>Semi-special rate : </td></label> 
                    <td><input type="text" name="lname"  value='<?php echo $data['hrate_semispl'];?> '> <br></td>
                </tr>
                <tr>
                    <td> <label>Special rate : </label></td>
                    <td><input type="text" name="lname"  value='<?php echo $data['hrate_spl'];?>'><br></td>
                </tr>
                <tr>
                    <td>  <label>General rate : </label></td>
                    <td><input type="text" name="lname"  value='<?php echo $data['hrate_general'];?> '><br></td>
                </tr>
                    </div>
                </table>
            </center>
            <input type="button" class="button button2" value="Update">
		</form>
    </body>
</html>