<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
    
    body{
	
	background-image: url("Main_page_bg.jpg");
        
	background-repeat:no-repeat;
       
	background-size:cover;
    
}
    .container {
		  padding: 16px;
		}

    .button {
  background-color: blue; 
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}
    .button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
}

    body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: darkblue;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
    .blinking{
    animation:blinkingText 1.2s infinite;
}
@keyframes blinkingText{
    0%{     color: blue;    }
    49%{    color: blue; }
    60%{    color: transparent; }
    99%{    color:transparent;  }
    100%{   color: blue;    }
     
}
    .blinking{
        text-align: right;
    }
</style>
<title>HOSPITAL_RECOMMENDATION_SYSTEM</title>
    
	 <div class="container" style="background-color:#f1f1f1">
    <h1> <a href='sign_up.php'> <span class="blinking">                                                            Click HERE TO SIGN UP </span> </a></h1>
    </div>
    <br>
    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="about_us.html">About us</a>
  
  <a href="sign_up.php">sign up</a>
  
</div>

    <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
<script language="Javascript" type="text/javascript">
Banners = new Array('hospital1.jpg', 'hospital2.jpg', 'hospital3.jpg', 'hospital4.jpg', 'hospital5.jpg')
count = 0
function rotate() {
 if (document.images) {
  count++;
  if (count == Banners.length)
  {
    count = 0;
  }

 document.img1.src = Banners[count];
 setTimeout("rotate()", 3000);
}
}

</script>
</head>
<body onload ="rotate()" >
<center>
   <img src="hospital1.jpg" width="800" height="400" name="img1" />
        <br>
    <a href='login.php'><button class="button button2"  id="admin" value="Admin">Admin</button></a>
    <a href='user.php'><button class= "button button2" value="User">User </button></a>
   <br>
    
   
    

   
</center>

    <script>
        function newpg()
        {
            a=<a href="login.html"></a>
        }
    </script>
    

    </body>
</html>