<html>
    <head>
        <style>body {
	
	background-image: url("giphy.gif");
        
	background-repeat:no-repeat;
       
	background-size:cover;
} 
            </style>
    </head>
</html>
<?php 
session_start();
$conn=mysqli_connect("localhost","root","","project");

if(isset($_REQUEST["btn"]))
{
    $user=$_REQUEST["uname"];
    $_SESSION['un1']=$user;
    $pass=$_REQUEST["psw"];
    $res="select * from user where hospital_name='$user' && password='$pass'";
    $query=mysqli_query($conn,$res);
    $rowcount=mysqli_num_rows($query);
    if($rowcount==true)
    {
        echo"<script>alert('Login Successfully');window.location='Admin_homepage.php'</script>";
    }
    else
    {
        echo "<script>alert('Incorrect UserName Or Password');window.location='login.php'</script>";
    }
}

?>
