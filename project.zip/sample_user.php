<html>
    <head>
        <style>
            body{
	
	background-image: url("outputbg.jpg");
        
	background-repeat:no-repeat;
       
	background-size:cover;
}
            </style>
    </head>
</html>
<table border="1">
  <tr>
     <th>HOSPITAL ID</th>
	 <th>HOSPITAL NAME</th>
	 <th>HOSPITAL ADDRESS</th>
	 <th>DOCTOR NAME</th>
	 <th>CITY NAME</th>
       <th>Details</th>
      <th>Ratings</th>
      
<?php
$conn=mysqli_connect("localhost","root","","project");
$set=$_POST['dname'];
$city=$_POST['cname'];
if($set AND $city)
{
    $show="SELECT * FROM hospital where disease_name='$set'AND city_name='$city'";
	
    $result1=mysqli_query($conn,$show);
     /*$sql="SELECT hospital.hospital_id,hospital.hospital_name,hospital.doctor_name,reviews.ratings FROM hospital,reviews WHERE hospital.hospital_id=reviews.hospital_id";
    $result2=mysqli_query($conn,$sql);*/
    
    while($row=mysqli_fetch_array($result1))
	{
        $sql = "SELECT * FROM reviews WHERE hospital_id='".$row['hospital_id']."'";
        $result2=mysqli_query($conn,$sql);
		echo "<tr>";
		echo "<td>";
        echo $row['hospital_id'];
		echo "</td>";
		echo "<td>";
        echo $row['hospital_name'];
		echo "</td>";
		echo "<td>";
        echo $row['hospital_address'];
		echo "</td>";
		echo "<td>";
        echo $row['disease_name'];
		echo "</td>";
		echo "<td>";
        echo $row['city_name'];
		echo "</td>";
            echo"<td><a href='detail.php?hospital_id=".$row['hospital_id']."'>click for more details</a></td>";
            while($row=mysqli_fetch_array($result2))
    {
        
        
        echo "<td> <img  src='".$row['ratings'].".PNG'>";
        echo "</td> ";  
		echo "</tr>";
        echo"<br>";
    }
    }

}
else{
    echo "noting to find";
    } 
	
?>

</table>