<html>
    <head>
        <style>
            body{
	
	background-image: url("bg.jpg");
        
	background-repeat:no-repeat;
       
	background-size:cover;
                
}
            </style>
    </head>
</html>
<?php
$conn=mysqli_connect("localhost","root","","project");
//$q="select * from users where fname like '%abc'";
$q="select * from hospital where hospital_id>5";
$result=mysqli_query($conn,$q);

//echo mysqli_num_rows($result);
//echo "<a href='insert-form.php'>Add New Record</a>";,.
echo "<center>";
echo "<table border=1>";
echo "<tr><th>Hospital ID</th><th>Hospital Name</th><th>Update</th></tr>";
//while($row=mysqli_fetch_row($result))
//while($row=mysqli_fetch_assoc($result))
while($row=mysqli_fetch_array($result))

{
	//echo '<pre>';
	//print_r($row);
	echo "<tr><td>". $row['hospital_id']."</td><td>". $row['hospital_name']."</td><td><a href='update_hosp.php?hospital_id=".$row['hospital_id']."'>update</a></td></tr>";
}

echo"</table>";
echo "</center>";
?>