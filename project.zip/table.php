<html>
    <head>
        <style>   
            body {
	
	background-image: url("tablebg.jpg");
        
	background-repeat:no-repeat;
       
	background-size:cover;
} 
            th {
  background-color: blue;
  color: white;
            }
            .serif {
  font-family: "Times New Roman", Times, serif;
                font-size: 20px;
                font-weight: 100;
                
}
            body {
  color: black;
}
            </style>
    </head>
</html>
<?php
$conn=mysqli_connect("localhost","root","","project");
//$q="select * from users where fname like '%abc'";
$q="select * from hospital where hospital_id>5";
$result=mysqli_query($conn,$q);

//echo mysqli_num_rows($result);
//echo "<a href='insert-form.php'>Add New Record</a>";

echo "<table border=1>";
echo "<tr><th>Hospital ID</th><th>Hospital Name</th><th>Doctor Name</th><th>Hospital Address</th><th>Start Time</th><th>End Time</th><th>Disease Name</th><th>City Name</th><th>Contact No</th><th>Hospital Rate - Icu</th><th>Hospital Rate-semispl</th><th>Hospital Rate-Special</th><th>Hospital Rate - General</th></tr>";
//while($row=mysqli_fetch_row($result))
//while($row=mysqli_fetch_assoc($result))
while($row=mysqli_fetch_array($result))

{
	//echo '<pre>';
	//print_r($row);
	echo "<tr><td>". $row['hospital_id']."</td><td>". $row['hospital_name']."</td><td>". $row['doctor_name']."</td><td>". $row['hospital_address']."</td><td>". $row['hosp_start_time']."</td><td>". $row['hosp_end_time']."</td><td>". $row['disease_name']."</td><td>". $row['city_name']."</td><td>". $row['cont_no']."</td><td>". $row['hrate_ICU']."</td><td>". $row['hrate_semispl']."</td><td>". $row['hrate_spl']."</td><td>". $row['hrate_general']."</td></tr>";
}

echo "</table>"
    

?>