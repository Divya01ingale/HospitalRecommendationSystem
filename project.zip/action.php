<html>
    <head>
        <style>
            
    body{
	
	background-image: url("deletebg.jpg");
        
	background-repeat:no-repeat;
       
	background-size:cover;
} 
            .blinking{
    animation:blinkingText 1.2s infinite;
}
@keyframes blinkingText{
    0%{     color: red;    }
    49%{    color: red; }
    60%{    color: transparent; }
    99%{    color:transparent;  }
    100%{   color: red;    }
     
}
  </style>
<center> 
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <h1>  <span class="blinking">                                                            HOSPITAL ADDED SUCCESSFULLY </span> </h1>
        </center> 
    </head>
</html>
<?php 
$conn = mysqli_connect("localhost" , "root" , "", "project");
if($conn->connect_error)
{
    die('Could be connect;'. $conn->connect_error());
    
}
echo "Connected";
echo"<br>";
$hname=$_REQUEST['hname'];
$drname=$_REQUEST['drname'];
$haddress=$_REQUEST['haddress'];

$stime=$_REQUEST['stime'];
$etime=$_REQUEST['etime'];
$dname=$_REQUEST['dname'];
$cityname=$_REQUEST['cityname'];
$contno=$_REQUEST['contno'];
$icurate=$_REQUEST['icurate'];
$semisplrate=$_REQUEST['semisplrate'];
$splrate=$_REQUEST['splrate'];
$generalrate=$_REQUEST['generalrate'];


if(isset($_REQUEST['btn'])){
    
    $sql="INSERT INTO `hospital` (`hospital_name`, `doctor_name`, `hospital_address`, `hosp_start_time`, `hosp_end_time`, `disease_name`, `city_name`, `cont_no`, `hrate_ICU`, `hrate_semispl`, `hrate_spl`, `hrate_general`) VALUES ('$hname', '$drname', '$haddress',  '$stime', '$etime', '$dname','$cityname', '$contno',  '$icurate', '$semisplrate', '$splrate', '$generalrate')";
    
    if(!mysqli_query($conn,$sql))
    {
        die('Error: '.mysqli_error($conn));
        
    }
    echo "succesful";
}

?>