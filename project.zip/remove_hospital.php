<html>
	<head>
		<title>Remove Hospital</title>
		<style>
          body {
	
	background-image: url("bg.jpg");
        
	background-repeat:no-repeat;
       
	background-size:cover;
}   
		.cancelbtn {
		  width: auto;
		  padding: 10px 18px;
		  background-color: #f44336;
		  }

		.container {
		  padding: 16px;
		}
		</style>
	</head>
	<body>
        <?php
        $conn=mysqli_connect("localhost", "root", "", "project");
        $q="select * from hospital";
        $result=mysqli_query($conn,$q);

        if(isset($_POST['dbtn']))
        {
            $val = $_POST['hospital_name'];
            header('location:delete.php?name='.$val);
        }
        ?>
	<center>
	<br><br>
	
	<form  method="post">

 <div class="container">
    <label for="uname"><b>Select Hospital To Delete</b></label>
    <select name="hospital_name" required>
    <?php
    while($row=mysqli_fetch_array($result))
    {
        echo "<option value='$row[1]'>".$row[1]."</option>";

    }
    ?>
	</select>
	<br>
	<br>
 
	 <div class="container" style="background-color:#f1f1f1">
  	  <button type="submit" class="cancelbtn" name="dbtn">DELETE</button>
	    
	  </div>
        </div>
	</form>
	</center>
	</body>
</html>