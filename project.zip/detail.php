<html>
    <head>
        <style>
            body{
	
	background-image: url("detailbg.jpg");
        
	background-repeat:no-repeat;
       
	background-size:cover;
}
            
            .serif {
  font-family: "Times New Roman", Times, serif;
                 font-size: 20px;
                
}
            body {
  color: black;
}
 table {
  border-collapse: collapse;
  width: 70%;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

tr:hover {background-color:#f5f5f5;}
          
        </style> 
    </head>
    <body>
        <?php
		$hospital_id=$_REQUEST['hospital_id'];
		$conn=mysqli_connect("localhost","root","","project");
		$res=mysqli_query($conn,"select * from hospital where hospital_id=$hospital_id");
		$data=mysqli_fetch_array($res);
        ?>
        <form  method="post">
            <center>
                <div class="serif">
            <table border="1"> 
                <tbody>
			<tr>
                <td><label>Hospital Name : </label></td>
                <td><?php echo $data['hospital_name']; ?></td><br><br>
                </tr>
                <tr>
                    <td><label>Hospital Address : </label></td>
                    <td><?php echo $data['hospital_address'];?></td><br><br>
                </tr>
                <tr>
                    <td><label>Doctor Name : </label></td>
                    <td><?php echo $data['doctor_name'];?></td><br><br>
                </tr>
                <tr>
                    <td><label>Contact No : </label></td>
                    <td><?php echo $data['cont_no'];?></td><br><br>
                </tr>
                <tr>
                    <td><label>Hospital Time : </label></td>
                    <td> <?php echo $data['hosp_start_time']; ?> TO <?php echo $data['hosp_end_time']; ?></td><br><br>
                </tr>
                <tr>
                    <td><label>Hospital City : </label></td>
                    <td><?php echo $data['city_name'];?></td><br><br>
                </tr>
                <tr>
                    <td><label>Disease Name : </label></td>
                    <td><?php echo $data['disease_name'];?></td><br><br>
                </tr>
                <tr>
                    <td><label>ICU rate : </label></td>
                    <td><?php echo $data['hrate_ICU'];?><br></td>
                </tr>
                <tr>
                    <td><label>Semi-special rate : </label></td>
                    <td><?php echo $data['hrate_semispl'];?><br></td>
                </tr>
                <tr>
                    <td><label>Special rate : </label></td>
                    <td><?php echo $data['hrate_spl'];?><br></td>
                </tr>
                <tr>
                    <td><label>General rate : </label></td>
                    <td><?php echo $data['hrate_general'];?><br></td>
                </tr>
                </tbody>
            </table>
                </div>
            </center>
		</form>
    </body>
</html>